package com.simplecoding.simpledmsreactlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleDmsReactLoginApplicationTests {

    @Test
    void contextLoads() {
    }

}
