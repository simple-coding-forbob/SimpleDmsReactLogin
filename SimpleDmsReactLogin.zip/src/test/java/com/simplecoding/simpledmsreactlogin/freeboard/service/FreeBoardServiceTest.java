package com.simplecoding.simpledmsreactlogin.freeboard.service;

import com.simplecoding.simpledmsreactlogin.auth.dto.SecurityUserDto;
import com.simplecoding.simpledmsreactlogin.freeboard.dto.FreeBoardDto;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.HashSet;
import java.util.Set;

@Log4j2
@SpringBootTest
class FreeBoardServiceTest {

    @Autowired
    private FreeBoardService freeBoardService;

    //  TODO: 테스트 하기 전에 항상 실행되는 메소드입니다. 테스트 전에 강제 로그인 시킵니다.
    @BeforeEach
    void setUp() {
        String email="forbob@naver.com";  // 계정
        String password="123456";         // 암호
        GrantedAuthority authority = new SimpleGrantedAuthority("ROLE_ADMIN");
        Set<GrantedAuthority> authorities = new HashSet<>();
        authorities.add(authority);       // 권한들

        SecurityUserDto securityUserDto = new SecurityUserDto(email, password, authorities);

        // 인증 유저 만들기
        UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken(securityUserDto, securityUserDto.getPassword(), authorities);

        // 강제 로그인 된 상태가 됩니다, 이제 아래 테스트를 하시면 로그인 된 상태로 테스트 됩니다.
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

    @Test
    void save() {
        //		1) 테스트 조건: Dept(dno,dname,loc)
        FreeBoardDto freeBoardDto=new FreeBoardDto();
        freeBoardDto.setTitle("제목");
        freeBoardDto.setContent("내용");
//		2) 실제 메소드실행
        freeBoardService.save(freeBoardDto);
//		3) 검증(확인): 로그 , DB 확인, assert~ (DB확인)
    }

    @Test
    void selectFreeBoardList() {
        Pageable pageable= PageRequest.of(1, 3);
        String searchKeyword="";
        Page<FreeBoardDto> page=freeBoardService.selectFreeBoardList(searchKeyword, pageable);
        log.info(page.getContent());

    }

    @Test
    void findById() {
        Long fid=(long)1;
        FreeBoardDto freeBoardDto=freeBoardService.findById(fid);
        log.info(freeBoardDto);

    }

    @Test
    void updateFromDto() {
        //		1) 테스트 조건: Dept(dno,dname,loc)
        FreeBoardDto freeBoardDto=new FreeBoardDto();
        freeBoardDto.setFid((long)1);
        freeBoardDto.setTitle("제목");
        freeBoardDto.setContent("내용2");

        freeBoardService.updateFromDto(freeBoardDto);
    }

    @Test
    void deleteById() {
        Long fid=(long)6;
        freeBoardService.deleteById(fid);
    }
}